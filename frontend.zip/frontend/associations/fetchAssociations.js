import { BASE_URL, getToken } from "../utils/utils.js";

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const res = await fetch(`${BASE_URL}/associations`, {
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    });

    if (res.ok) {
      const associations = await res.json();
      const tableBody = document.getElementById("associations-table");
      associations.forEach(({ name, description }) => {
        const row = `
          <tr>
            <td>Logo</td>
            <td>${name}</td>
            <td>${description}</td>
            <td>Acciones</td>
          </tr>
        `;
        tableBody.innerHTML += row;
      });
    } else {
      console.error("Error al cargar asociaciones.");
    }
  } catch (err) {
    console.error("Error en asociaciones:", err);
  }
});
