import { BASE_URL } from "../utils/constants.js";
import { getToken } from "../utils/utils.js";
import { renderMessages } from "../messages/renderMessage.js";

export async function fetchAssociationDetails(id) {
    try {
        const res = await fetch(`${BASE_URL}/associations/${id}`, {
            headers: { Authorization: `Bearer ${getToken()}` },
        });

        if (res.ok) {
            const association = await res.json();
            document.getElementById("association-name").textContent = association.name;
            document.getElementById("association-image").src =
                association.image || "../styles/default-logo.png";
            document.getElementById("association-description").textContent =
                association.description;
        } else {
            console.error("Error al cargar detalles de la asociación");
        }
    } catch (error) {
        console.error("Error al cargar detalles de la asociación:", error);
    }
}

export async function initializeDetailsPage() {
    const params = new URLSearchParams(window.location.search);
    const associationId = params.get("id");

    if (associationId) {
        await fetchAssociationDetails(associationId);
        renderMessages(associationId);
    }
}
