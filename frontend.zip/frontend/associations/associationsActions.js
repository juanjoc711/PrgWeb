import { BASE_URL, getToken } from "../utils/utils.js";

export async function joinAssociation(associationId) {
  try {
    const res = await fetch(`${BASE_URL}/associations/${associationId}/join`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    });

    if (res.ok) {
      alert("Te has unido a la asociación.");
    } else {
      console.error("Error al unirse a la asociación:", await res.text());
    }
  } catch (err) {
    console.error("Error al unirse a la asociación:", err);
  }
}

export async function leaveAssociation(associationId) {
  try {
    const res = await fetch(`${BASE_URL}/associations/${associationId}/leave`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${getToken()}`,
      },
    });

    if (res.ok) {
      alert("Has dejado la asociación.");
    } else {
      console.error("Error al dejar la asociación:", await res.text());
    }
  } catch (err) {
    console.error("Error al dejar la asociación:", err);
  }
}
