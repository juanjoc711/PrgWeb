import { getToken, clearToken, setToken } from "./utils/utils.js";

document.addEventListener("DOMContentLoaded", () => {
  const userDropdown = document.getElementById("userDropdown");
  const userInitial = document.getElementById("user-initial");

  // Mostrar inicial de usuario si hay token
  const token = getToken();
  if (token) {
    const username = JSON.parse(atob(token.split(".")[1])).username;
    userDropdown.style.display = "block";
    userInitial.textContent = username.charAt(0).toUpperCase();
  } else {
    userDropdown.style.display = "none";
  }

  // Logout
  document.getElementById("logout").addEventListener("click", () => {
    clearToken();
    window.location.href = "./auth/login.html";
  });
});
