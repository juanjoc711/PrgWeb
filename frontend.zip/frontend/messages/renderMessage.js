import {
    fetchMessages,
    createMessage,
    updateMessage,
    deleteMessage,
} from "./messages.js";
import { getUserId, getUserRole } from "../utils/utils.js";

// Renderizar mensajes en el contenedor
export async function renderMessages(associationId) {
    const messageContainer = document.getElementById("messages-container");
    messageContainer.innerHTML = ""; // Limpia el contenedor antes de renderizar

    const messages = await fetchMessages(associationId);

    messages.forEach((message) => {
        const messageDiv = document.createElement("div");
        messageDiv.classList.add("message", "mb-3", "p-3", "border", "rounded");

        // Encabezado del mensaje: Autor + Fecha
        const messageHeader = document.createElement("div");
        messageHeader.classList.add("d-flex", "justify-content-between");

        const authorSpan = document.createElement("span");
        authorSpan.textContent = `${message.author.username}`;
        authorSpan.classList.add("fw-bold");

        const dateSpan = document.createElement("span");
        dateSpan.textContent = new Date(message.createdAt).toLocaleString();
        dateSpan.classList.add("text-muted", "small");

        messageHeader.appendChild(authorSpan);
        messageHeader.appendChild(dateSpan);

        const contentDiv = document.createElement("div");
        contentDiv.textContent = message.content;

        messageDiv.appendChild(messageHeader);
        messageDiv.appendChild(contentDiv);

        // Opciones de edición/eliminación (si es autor o admin)
        const actionsDiv = document.createElement("div");
        actionsDiv.classList.add("d-flex", "gap-2", "mt-2");

        if (message.author._id === getUserId() || getUserRole() === "admin") {
            const editButton = document.createElement("button");
            editButton.classList.add("btn", "btn-warning", "btn-sm");
            editButton.innerHTML = '<i class="fa fa-edit"></i>';
            editButton.title = "Editar mensaje";
            editButton.onclick = async () => {
                const newContent = prompt("Edita tu mensaje:", message.content);
                if (newContent && newContent !== message.content) {
                    const updatedMessage = await updateMessage(
                        associationId,
                        message._id,
                        newContent
                    );
                    if (updatedMessage) renderMessages(associationId);
                }
            };

            const deleteButton = document.createElement("button");
            deleteButton.classList.add("btn", "btn-danger", "btn-sm");
            deleteButton.innerHTML = '<i class="fa fa-trash"></i>';
            deleteButton.title = "Eliminar mensaje";
            deleteButton.onclick = async () => {
                const success = await deleteMessage(associationId, message._id);
                if (success) renderMessages(associationId);
            };

            actionsDiv.appendChild(editButton);
            actionsDiv.appendChild(deleteButton);
        }

        messageDiv.appendChild(actionsDiv);
        messageContainer.appendChild(messageDiv);
    });

    // Agregar formulario para enviar nuevos mensajes
    const messageForm = document.createElement("form");
    messageForm.classList.add("d-flex", "mt-4", "gap-2");
    messageForm.onsubmit = async (e) => {
        e.preventDefault();
        const content = e.target.messageInput.value.trim();
        if (content) {
            const newMessage = await createMessage(associationId, content);
            if (newMessage) {
                renderMessages(associationId);
                e.target.messageInput.value = "";
            }
        }
    };

    const messageInput = document.createElement("input");
    messageInput.type = "text";
    messageInput.name = "messageInput";
    messageInput.classList.add("form-control");
    messageInput.placeholder = "Escribe un mensaje...";

    const sendButton = document.createElement("button");
    sendButton.classList.add("btn", "btn-primary");
    sendButton.innerHTML = '<i class="fa fa-paper-plane"></i>';

    messageForm.appendChild(messageInput);
    messageForm.appendChild(sendButton);
    messageContainer.appendChild(messageForm);
}
