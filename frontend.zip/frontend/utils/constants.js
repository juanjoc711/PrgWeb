export const BASE_URL = "http://localhost:3000";

export const MESSAGES = {
  REGISTER_SUCCESS: "Usuario registrado con éxito.",
  LOGIN_SUCCESS: "Inicio de sesión exitoso.",
  REGISTER_ERROR: "Error al registrar el usuario.",
  LOGIN_ERROR: "Usuario o contraseña incorrectos.",
  LOAD_ASSOCIATIONS_ERROR: "No se pudieron cargar las asociaciones.",
};

export const ROUTES = {
  LOGIN: "./auth/login.html",
  REGISTER: "./auth/register.html",
  ASSOCIATIONS_LIST: "./associations/associations-list.html",
};
