import { BASE_URL } from "../utils/constants.js";
import { getToken, getUserId } from "../utils/utils.js";

// Cambiar el nombre de usuario
export async function changeUsername(newUsername) {
    try {
        const res = await fetch(`${BASE_URL}/auth/change-username`, {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${getToken()}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ newUsername }),
        });

        if (res.ok) {
            alert("Nombre de usuario cambiado con éxito.");
            window.location.reload();
        } else {
            const error = await res.json();
            alert(error.message || "Error al cambiar el nombre de usuario.");
        }
    } catch (error) {
        console.error("Error al cambiar el nombre de usuario:", error);
    }
}

// Cambiar la contraseña
export async function changePassword(currentPassword, newPassword) {
    try {
        const res = await fetch(`${BASE_URL}/auth/change-password`, {
            method: "PUT",
            headers: {
                Authorization: `Bearer ${getToken()}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ currentPassword, newPassword }),
        });

        if (res.ok) {
            alert("Contraseña cambiada con éxito.");
            window.location.reload();
        } else {
            const error = await res.json();
            alert(error.message || "Error al cambiar la contraseña.");
        }
    } catch (error) {
        console.error("Error al cambiar la contraseña:", error);
    }
}

// Renderizar información del perfil
function renderProfile() {
    const userId = getUserId();
    const profileIdElement = document.getElementById("profile-id");

    if (profileIdElement) {
        profileIdElement.textContent = `ID de usuario: ${userId}`;
    } else {
        console.error("Elemento con ID 'profile-id' no encontrado en el DOM.");
    }
}

// Manejar eventos del perfil
document.addEventListener("DOMContentLoaded", () => {
    // Renderiza el perfil solo cuando el DOM esté cargado
    if (document.getElementById("profile-id")) {
        renderProfile();
    }

    const changeUsernameForm = document.getElementById("change-username-form");
    if (changeUsernameForm) {
        changeUsernameForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const newUsername = document.getElementById("new-username").value.trim();
            if (newUsername) {
                await changeUsername(newUsername);
            }
        });
    }

    const changePasswordForm = document.getElementById("change-password-form");
    if (changePasswordForm) {
        changePasswordForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const currentPassword = document
                .getElementById("current-password")
                .value.trim();
            const newPassword = document.getElementById("new-password").value.trim();

            if (currentPassword && newPassword) {
                await changePassword(currentPassword, newPassword);
            }
        });
    }
});
