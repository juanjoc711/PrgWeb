import { BASE_URL } from "../utils/constants.js";
import { setToken } from "../utils/utils.js";

console.log("auth.js cargado correctamente");

// Función para registro
export async function register(username, password) {
  try {
    const res = await fetch(`${BASE_URL}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    if (res.ok) {
      alert("Registro exitoso. Por favor, inicia sesión.");
      window.location.href = "./login.html";
    } else {
      const error = await res.json();
      alert(error.message || "Error al registrar el usuario.");
    }
  } catch (err) {
    console.error("Error en el registro:", err);
    alert("Ocurrió un error al intentar registrar. Inténtalo más tarde.");
  }
}

// Función para login
export async function login(username, password) {
  try {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    if (res.ok) {
      const data = await res.json();
      setToken(data.token);
      alert("Inicio de sesión exitoso.");
      window.location.href = "../associations/associations-list.html";
    } else {
      const error = await res.json();
      alert(error.message || "Usuario o contraseña incorrectos.");
    }
  } catch (err) {
    console.error("Error en el login:", err);
    alert("Ocurrió un error al intentar iniciar sesión.");
  }
}

// Manejo de formularios
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const registerForm = document.getElementById("register-form");

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value.trim();
      login(username, password);
    });
  }

  if (registerForm) {
    registerForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const username = document.getElementById("register-username").value.trim();
      const password = document.getElementById("register-password").value.trim();
      register(username, password);
    });
  }
});
